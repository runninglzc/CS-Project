X = Xtrain;
y = ytrain;
[N,n] = size(X);
lam1 = 0.0001;
lam2 = 0.0001;

L = zeros(n+1,1); % L_{n+1} is L_b
for j = 1:n
  Lj = lam1;
  for i = 1:N
    Lj = Lj+ y(i)^2*X(i,j)^2/N;
  end
  L(j)=Lj;
end
L(n+1) = lam2+1; % might be a good idea to isolate bias. idk

p = zeros(n/k+1,1); % p contains prob of selecting each block. Bias has its own block.
for j = 1:n/k
    p(j)=sqrt(sum(L(k*(j-1)+1:k*j))); % j ~ sqrt(L_j); generalize to block.
end
p(n/k+1) = L(n+1); % bias term
p = p/sum(p); % normalize