% GD main code.
lam1=0.001; lam2=0.001; maxit=60000; tol=10^(-4); 
% spamdata: 2000 iter cost 1 min->5.5 sec, but not nearly converging yet (76% accuracy).
% spamdata: 10000 iter: 347 sec->27 sec, 84% training 86% test (obj still not converged)
% spamdata: 60000 iter: 173 sec, 88% training, 91% test
% gisette: 100 iter cost 20sec->2 sec, train 98.8% test 92.9%.
% gisette: 4408 iter, 18 sec, conv 1e-4. train 100% test 93.4%.
% gisette optimal obj: 0.22986663
tic
[w,b,hist_obj] = LR_gd(Xtrain,ytrain,lam1,lam2,maxit,tol);
toc