function [w,b,hist_obj,grad_w,grad_b] = LR_nuacdm(X,y,lam1,lam2,maxit,tol,k)
% k: # of coordinates in each block. Need N/k to be integer.
% nuacdm: j ~ sqrt(L_j), instead of cyclic/uniform. Can pre-approx L_j:
% L_j ~ lm1 + 1/N sum_{i=1}^n y_i^2 x_{ij}^2.
% Generalize to block cd: 
% Prob(block_p) ~ sqrt(sum(L_j, j \in block_p))  (or max?)
% (Smoothness for b:) L_{d+1} ~ lm2 + 1/N sum_{i=1}^n y_i^2.
% block size: spam: k=3. gisette: k=1000,500,...
% spamdata, tol=0.01, maxit=2000: 40 sec. 88%, 90%.
%   the while loop in backtrack is most time-consuming. idk what i can do
%   to improve... p is the issue (~96% chance to select last index)
% gisette, tol=0.01, ite=264*5: 8 sec. 100%, 93.4%
% gisette, tol=0.0001, ite=4493*5: 135 sec, 100%, 93.6%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% steepest gradient descent for logistic regression problem:
%
% min_{w,b} 1/N*sum_{i=1}^N log( 1+exp[-yi*(w'*xi+b)] ) 
%           + .5*lam1*w'*w + .5*lam2*b^2 
%
% input:
%       X(i,:) is the i-th data point
%       y(i) is the label
%       lam1, lam2: parameters in the model
%       maxit: maximum number of iterations
%       tol: stopping tolerance
%
% output:
%       w, b: approximation solution of the model
%       hist_obj: objective values at all iterates
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% get size of the data
%
% N is the number of sample points
% n is the dimension of each sample point

[N,n] = size(X);

%% initialization
w = zeros(n,1);
b = 0;

[grad_w, grad_b] = eval_grad(w,b); %%

obj = eval_obj(w,b); %%
hist_obj = obj;
iter = 0; 

% Pre-estimate L_i:
% could use L = lm1+1/N*y'.^2*X.^2, but below only take 0.001s so w.e.
L = zeros(n+1,1); % L_{n+1} is L_b
for j = 1:n
  Lj = lam1;
  for i = 1:N
    Lj = Lj+ y(i)^2*X(i,j)^2/N;
  end
  L(j)=Lj;
end
L(n+1) = lam2+1; % might be a good idea to isolate bias. idk

p = zeros(n/k+1,1); % p contains prob of selecting each block. Bias has its own block.
for j = 1:n/k
    p(j)=sqrt(sum(L(k*(j-1)+1:k*j))); % j ~ sqrt(L_j); generalize to block.
end
p(n/k+1) = L(n+1); % bias term
p = p/sum(p); % normalize

%% main iterations
tic
while iter < maxit & ... % 1 iter cost 0.05 sec. 5 times slower than cyclic!
        norm(grad_w) + norm(grad_b) >= tol*max(1, norm(w)+norm(b))
    
    iter = iter + 1;
    % "write your own code to choose the step size alpha:"
    % Armijo's Cond: (s \in (0,1). ex: s=1/2) 
    % Backtrack: start from 0.1, *1/2 every time Armijo fails. (can change)
    %alpha1 = 0.1;
    %alpha2 = 0.1;% (can change)
    s=1/2; % (can change)
    % if backtracking is used, another while-loop should be inserted here:
    
    % below for-loop cost 0.05 sec.
    for temp2 = 1:n/k % 1:n/k = swept across n coord. can tune this larger.
        % now sample j:
       temp3 = rand; % ~U(0,1)
       temp4 = 0; % used below
       
       for temp5 = 1:n/k+1 % this for-loop cost 0.000006 sec. not issue.
           temp4 = temp4+p(temp5);
           if temp3 < temp4
               j = temp5;
               break
           end
       end
       
       alpha1 = 0.1; % this is the biggest time-consuming issue.
       % can't even tune down.. else the accuracy is much worse
       alpha2 = 0.1;
      
       % below 'if' cost 0.003 sec: (cost entirely in the first 'while'...)
      if j < n/k+1 % i.e. not bias term:
       partial_w = eval_partial(w,b,j); %%% can optimize below:
       
       %v = zeros(n,1);
       %v(k*(j-1)+1:k*j) = partial_w;
       % while eval_obj(w-alpha1*v,b) ... % this 'while' cost 0.003 sec! Most time-consuming.
       %     > eval_obj(w,b)-s*alpha1*(norm(v)^2)
       temp_obj = eval_obj(w,b);
       temp_norm2 = norm(partial_w)^2;
       while eval_obj_partw(w(k*(j-1)+1:k*j)-alpha1*partial_w,j) > temp_obj-s*alpha1*temp_norm2
           % this 'while' cost 75% total time..
          alpha1=1/4*alpha1; % can tune from 1/2 to 1/4 => save 40% time without hurting much.
        end
        
          w((k*(j-1)+1:k*j)) = w((k*(j-1)+1:k*j)) - alpha1*partial_w;
      else % bias term:
          grad_b = eval_gradb(w,b);
          while eval_obj(w,b-alpha2*grad_b) ...
            > eval_obj(w,b)-s*alpha2*(norm(grad_b)^2)
            alpha2=1/2*alpha2; % (can change)
          end
          b = b - alpha2*grad_b;
      end
      
    end
    
       
    
    % below step is only use to check stop crit!! not good too often!!
    [grad_w, grad_b] = eval_grad(w,b);
    
    obj = eval_obj(w,b);
    
    % save the objective value
    hist_obj = [hist_obj; obj];
    
    %iter
end % of main iteration
toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function [grad_b] = eval_gradb(w,b) % avoid for loop!     
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        grad_b=lam2*b+sum(temp);
    end 
    function [partial_w] = eval_partial(w,b,j) %
        % (Update: Can improve by evaluating temp only at every outer
        %iter!! No NVM...)
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        partial_w=lam1*w(k*(j-1)+1:k*j)+(temp*X(:,k*(j-1)+1:k*j))';
    end 
    function [grad_w, grad_b] = eval_grad(w,b) % avoid for loop!      
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        grad_w=lam1*w+(temp*X)';
        grad_b=lam2*b+sum(temp);
    end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function obj = eval_obj(w,b) % avoid for loop! 
        obj=lam1/2*norm(w)^2+lam2/2*b^2+sum(log(1+exp(-(X*w+b).*y))/N);
    end 

    function obj = eval_obj_partw(wj,j) % s.t. calling avoids extrapolation
        % we care about jth block. wj is the vector of jth block.
        tempw = w;
        tempw(k*(j-1)+1:k*j) = wj;
        obj = eval_obj(tempw,b);
    end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end