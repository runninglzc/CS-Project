% Data: c; A,b ~ U[0,1]; Q ~ random PSD matrix with mean = I, covariance = I.
%%% Now consider x>=0! Usually infeasible!!
m=100;
n=500;
A=rand(m,n);
b=rand(m,1);
Q=wishrnd(eye(n),n/10); % 2nd parameter = degree of freedom.
temp=0.1; Q=Q+temp*eye(n); % in case not PSD. Problem harder as temp decreases.
c=rand(n,1);

tol=10^(-6); % (try) stop crit of FISTA: |grad(L(x^l,y^k))| < tol
out_iter=50; % # outer iteration
beta=1;
in_iter=500; % max # inner iter

tic
x2 = iALM_qp2(Q,c,A,b,out_iter,in_iter,tol,beta); % computed optimal solution
toc

%%
cvx_begin
    cvx_precision high
    variable xopt(n) nonnegative; %%% x >= 0
    minimize( 1/2*xopt'*Q*xopt+c'*xopt );
    subject to
    A*xopt==b;
cvx_end
obj_opt = cvx_optval;

%%
obj = 1/2*x2'*Q*x2+c'*x2 % obj
constr = norm(A*x2-b) % constraint