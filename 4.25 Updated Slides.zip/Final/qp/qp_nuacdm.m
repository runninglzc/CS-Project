% QP Solver: (iALM, nuacdm)
% min 1/2*x'Qx+c'x s.t. Ax=b.
% input: Q,c,A,b; out_iter, in_iter, tol, beta
% output: x
% May add block structure later.

function [x objhist] = qp_nuacdm(Q,c,A,b,out_iter,in_iter,tol,beta)
objhist=zeros(out_iter,1); % stores obj hist every out-iter
% L(x,y) = 1/2*x'Qx+c'x+<y,Ax-b>+beta/2 |Ax-b|^2
% Note: grad_x(L(x,y))=Qx+c+A'y+beta*A'(Ax-b)
[n, d]=size(A);
x=zeros(d,1);
y=zeros(n,1);
yy=zeros(d,1); % GD iterate
zz=zeros(d,1); % MD iterate
%LL=norm(Q)+beta*norm(A)^2; % grad lip const.
LL=norm(Q+beta*A'*A); % use this when d is not so big. 
L=zeros(d,1);
p=zeros(d,1);
for j = 1:d % compute L_j
    L(j)=Q(j,j)+beta*norm(A(:,j))^2;
    p(j)=sqrt(L(j));
end
S=sum(p);
p=p/S;
sigma = eigs(Q,1,'smallestabs'); % smallest eigenvalue
tau = 2/(1+sqrt(1+4*S^2/sigma));
eta = 1/(tau*S^2);
total_iter = 0; % record total iter.
for k=1:out_iter
    for l=1:in_iter % nuacdm for x subproblem:
        total_iter = total_iter+1;
       temp3 = rand; % ~sample j:
       temp4 = 0; 
       for temp5 = 1:d 
           temp4 = temp4+p(temp5);
           if temp3 < temp4
               j = temp5;
               break
           end
       end
       
        x = tau*zz+(1-tau)*yy;
        partial_x=Q(j,:)*x+c(j)+A(:,j)'*y+beta*A(:,j)'*(A*x-b); % partial x_j
        yy = x;
        yy(j) = yy(j)-1/L(j)*partial_x; % GD
        zz = zz+eta*sigma*x;
        zz(j) = zz(j)-eta/p(j)*partial_x;
        zz = zz/(1+eta*sigma); % MD
    end
    y=y+beta*(A*x-b);
    obj = objf(x);
    objhist(k)=obj;
    if norm(Q*x+c+A'*y+beta*A'*(A*x-b))<tol % stop when |grad_x(L(x,y))| small
            break % only check once a while. 
    end
end
total_iter
out_iter

function obj2 = eval_AL_full(x) % L(x,y). Most time is spent here! (80% time)
    obj2 = 1/2*x'*Q*x+c'*x+y'*(A*x-b)+beta/2*norm(A*x-b)^2; %Most time is spent here! (80% time)
end 

function obj3 = eval_AL(xj,j) % L(x,y). only dep on jth coord of x!!
    %obj2 = 1/2*x'*Q*x+c'*x+y'*(Ax-b)+beta/2*norm(Ax-b)^2;
    xtemp = x;
    xtemp(j) = xj;
    obj3 = eval_AL_full(xtemp);
end
function r = objf(x)
r=1/2*x'*Q*x+c'*x;
end
end 