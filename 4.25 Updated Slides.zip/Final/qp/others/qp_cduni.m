% QP Solver: (iALM, CD(uni))
% min 1/2*x'Qx+c'x s.t. Ax=b.
% input: Q,c,A,b; out_iter, in_iter, tol, beta
% output: x
% somehow this is bad...
% Used const step size!! Should backtrack instead!!
% May add block structure later.
% uni: 50*500, 6 sec, -12, 0.22. (bad)

function x = qp_cduni(Q,c,A,b,out_iter,in_iter,tol,beta)
% L(x,y) = 1/2*x'Qx+c'x+<y,Ax-b>+beta/2 |Ax-b|^2
% Note: grad_x(L(x,y))=Qx+c+A'y+beta*A'(Ax-b)
[n, d]=size(A);
x=zeros(d,1);
y=zeros(n,1);
%L=norm(Q)+beta*norm(A)^2; % grad lip const.
L=norm(Q+beta*A'*A); % use this when d is not so big. 
%alpha = 1/L; % should backtrack. const step size is too bad.
% const step: 50*5000 iter cost 8.52 sec. (very bad result, since step size too small)
% backtrack: 50*500 iter cost 5 sec: obj = -20, constr=0.6 (not converged)
% backtrack: 80% time is spent on eval_AL_full.
% backtrack: 50*5000: 46 sec, -82, 0.16
for k=1:out_iter
    for l=1:in_iter
        j = unidrnd(d);
        
        alpha = 0.1; % backtrack armijo: can tune.
        s = 0.5; % can tune.
        partial_x=Q(j,:)*x+c(j)+A(:,j)'*y+beta*A(:,j)'*(A*x-b); % partial x_j
        %v=zeros(d,1);
        %v(j)=partial_x;
        %while eval_AL(x-alpha*v) ... % sec
        %    > eval_AL(x)-s*alpha*(norm(v)^2)
        temp_obj = eval_AL_full(x);
        while eval_AL(x(j)-alpha*partial_x,j) > temp_obj-s*alpha*partial_x^2
            % correcting above RHS actually made obj worse...
          alpha=1/2*alpha; % (can change)
        end
        
        x(j) = x(j) - alpha * partial_x;
    end
    y=y+beta*(A*x-b);
    if norm(Q*x+c+A'*y+beta*A'*(A*x-b))<tol % stop when |grad_x(L(x,y))| small
            break % only check once a while. 
    end
end

% function obj = eval_obj_full(x) % without constraint
%     obj = 1/2*x'*Q*x+c'*x;
% end 

function obj2 = eval_AL_full(x) % L(x,y). Most time is spent here! (80% time)
    obj2 = 1/2*x'*Q*x+c'*x+y'*(A*x-b)+beta/2*norm(A*x-b)^2; %Most time is spent here! (80% time)
end 

function obj3 = eval_AL(xj,j) % L(x,y). only dep on jth coord of x!!
    %obj2 = 1/2*x'*Q*x+c'*x+y'*(Ax-b)+beta/2*norm(Ax-b)^2;
    xtemp = x;
    xtemp(j) = xj;
    obj3 = eval_AL_full(xtemp);
end 

end