function [w,b,hist_obj] = LR_newton(X,y,lam1,lam2,maxit,tol) % Newton
%% get size of the data
%
% N is the number of sample points
% n is the dimension of each sample point

[N,n] = size(X);

%% initialization
%
% other initial iterate can also be used
w = zeros(n,1);
b = 0;

% grad_w: the partial gradient of w
% grad_b: the partial gradient of b

% write your own function eval_grad to evaluate grad_w and grad_b
[grad_w, grad_b] = eval_grad(w,b); %%

% write your own function eval_obj(w,b)
obj = eval_obj(w,b); %%
hist_obj = obj;
iter = 0; 

[Hw,Hb] = eval_hessian(w,b);

%% main iterations
while iter < maxit & ...
        norm(grad_w) + norm(grad_b) >= tol*max(1, norm(w)+norm(b))
    
    iter = iter + 1;
    % "write your own code to choose the step size alpha:"
    alpha=1; % (can change)
    % update w and b
    
    w = w - alpha*Hw\grad_w; % Newton
    
    b = b - alpha*Hb\grad_b;
    
    % evaluate the gradient for next iteration
    
    [grad_w, grad_b] = eval_grad(w,b);
    [Hw,Hb] = eval_hessian(w,b);
    
    % write your own function eval_obj(w,b)
    obj = eval_obj(w,b);
    
    % save the objective value
    hist_obj = [hist_obj; obj];
    
end % of main iteration



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    function [grad_w, grad_b] = eval_grad(w,b) % avoid for loop! (function 20 times faster!)     
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        grad_w=lam1*w+(temp*X)';
        grad_b=lam2*b+sum(temp);
    end 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    function obj = eval_obj(w,b) % avoid for loop! (function 15 times faster!) 
        obj=lam1/2*norm(w)^2+lam2/2*b^2+sum(log(1+exp(-(X*w+b).*y))/N);
    end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%     function [hes_w,hes_b] = eval_hessian(w,b) % Correct but too long!!
%         hes_w=lam1*eye(n); % H=(Hw,Hwb;Hwb',Hb)
%         hes_b=lam2;
%         %hes_wb=zeros(n,1);
%         for i=1:N
%             for j=1:n % OK this double for loop takes forever when n big.
%                 temp=y(i)/N* (X(i,j)*y(i)*exp(-y(i)*(X(i,:)*w+b)))...
%                     /(1+exp(-y(i)*(X(i,:)*w+b)))^2;
%                 hes_w(:,j)=hes_w(:,j)+temp*X(i,:)';
%                 %hes_wb(j)=hes_wb(j)+temp;
%             end
%             hes_b=hes_b+y(i)^2/N* exp(-y(i)*(X(i,:)*w+b))/(1+exp(-y(i)*(X(i,:)*w+b)))^2;
%         end
%         %H=[hes_w,hes_wb;hes_wb',hes_b];
%     end 

    function [hes_w,hes_b] = eval_hessian(w,b) % same but without double for loop! much faster!
        temp=exp(-y.*(X*w+b));
        temp=y.^2.*temp./(1+temp)./(1+temp);
        hes_w=lam1*eye(n)+  X'*diag(y.^2.*temp)*X/N;
        hes_b=lam2+  sum(y.^2.*temp)/N;
    end 
end