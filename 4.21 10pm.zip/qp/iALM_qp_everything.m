%%% Didn't consider x>=0! Need fix!
% Try QP: works.
% min 1/2*x'Qx+c'x s.t. Ax=b.
% iALM, FISTA.
% Data: c; A,b ~ U[0,1]; Q ~ random PSD matrix with mean = I, covariance = I.
% grad_x(L(x,y))=Qx+c+A'y+beta*A'(Ax-b)
tic
m=100;
n=500;
A=rand(m,n);
b=rand(m,1);
Q=wishrnd(eye(n),n/10); % 2nd parameter = degree of freedom.
temp=0.1; Q=Q+temp*eye(n); % in case not PSD. Problem harder as temp decreases.
c=rand(n,1);

%[m n]=size(A);
tol=10^(-6); % (try) stop crit of FISTA: |grad(L(x^l,y^k))| < tol
out_iter=50; % # outer iteration
beta=1;
in_iter=500; % max # inner iter

x=zeros(n,1);
y=zeros(m,1);
normQ=norm(Q); 
normA=norm(A);
L=normQ+beta*normA^2; % grad lip const.
for k=1:out_iter
    z=x; % FISTA:
    t=1;
    for l=1:in_iter
        t_old=t;
        t=(1+sqrt(1+4*t^2))/2;
        x_old=x;
        x=z-(Q*z+c+A'*y+beta*A'*(A*z-b))/L;
        %norm(x) % test
        z=x+(t_old-1)/t*(x-x_old);
        if norm(abs(Q*x+c+A'*y+beta*A'*(A*x-b)))<tol % stop when |grad_x(L(x,y))| small? not sure.
            % k
            % l
            break
        end
    end
    
    y=y+beta*(A*x-b);
    %norm(y)
end
toc

%%
cvx_begin
    cvx_precision high
    variable xopt(n);
    minimize( 1/2*xopt'*Q*xopt+c'*xopt );
    subject to
    A*xopt==b;
cvx_end
obj_opt = cvx_optval;

%%
obj = 1/2*x'*Q*x+c'*x % obj
constr = norm(A*x-b) % constraint