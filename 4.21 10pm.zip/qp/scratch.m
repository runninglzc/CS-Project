Q=eye(2);
c=zeros(2,1);


%%
cvx_begin
    cvx_precision high
    variable xopt(n);
    minimize( 1/2*xopt'*Q*xopt+c'*xopt );
    subject to
    A*x==b;
cvx_end
obj_opt = cvx_optval;
