lam1=0.001; lam2=0.001; maxit=2000; tol=10^(-15); 
% spamdata: 10 iter: 3.64 sec->0.66 sec, 93%, 94%. 
tic
[w,b,hist_obj] = LR_newton(Xtrain,ytrain,lam1,lam2,maxit,tol);
toc