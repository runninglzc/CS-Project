% coordinate GD main code.
% k: # of coordinates in each block. Need n/k to be integer.

% spam: 3-block, 9485 out iter conv. 1e-4 (me 78 sec, 92.9% train, 94% test)
% gisette: 200-block, 100 out iter 421 sec not conv. 100% train, 93.3% test.
lam1=0.001; lam2=0.001; tol=10^(-2); 
tol=10^(-4);%%%
maxit=20000;
%maxit=100000;
k=1000;
%k=3; % block size
tic
%[w,b,hist_obj] = LR_cgd(Xtrain,ytrain,lam1,lam2,maxit,tol,k);
[w,b,hist_obj] = LR_nuacdm(Xtrain,ytrain,lam1,lam2,maxit,tol,k);
toc