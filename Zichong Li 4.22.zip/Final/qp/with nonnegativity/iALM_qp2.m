% QP Solver: (iALM, FISTA)
% min 1/2*x'Qx+c'x s.t. Ax=b.
% input: Q,c,A,b; out_iter, in_iter, tol, beta
% output: x
%%% Considered x>=0 now!!

function x = iALM_qp2(Q,c,A,b,out_iter,in_iter,tol,beta)
% L(x,y) = 1/2*x'Qx+c'x+<y,Ax-b>+beta/2 |Ax-b|^2
% Note: grad_x(L(x,y))=Qx+c+A'y+beta*A'(Ax-b)
[m n]=size(A);
%tol=10^(-6); % (try) stop crit of FISTA: |grad(L(x^l,y^k))| < tol
%out_iter=50; % # outer iteration
%beta=1;
%in_iter=500; % max # inner iter

x=zeros(n,1);
y=zeros(m,1);
normQ=norm(Q); 
normA=norm(A);
L=normQ+beta*normA^2; % grad lip const.
for k=1:out_iter
    z=x; % FISTA:
    t=1;
    for l=1:in_iter
        t_old=t;
        t=(1+sqrt(1+4*t^2))/2;
        x_old=x;
        x=z-(Q*z+c+A'*y+beta*A'*(A*z-b))/L;
        x = max(x,0); %%% x>=0
        z=x+(t_old-1)/t*(x-x_old);
        
%add normal cone of x>=0 to "stop crit when |grad_x(L(x,y))| small".
        I = find(x); % all index of zeros (x => nonzeros)
        temp = Q*x+c+A'*y+beta*A'*(A*x-b);
        temp(I) = min(temp(I),0);
        if norm(temp)<tol % stop when |grad_x(L(x,y))| small? not sure.
            break
        end
    end
    
    y=y+beta*(A*x-b);
end
end