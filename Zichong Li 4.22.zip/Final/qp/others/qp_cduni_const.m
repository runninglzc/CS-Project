% QP Solver: (iALM, CD(uni))
% min 1/2*x'Qx+c'x s.t. Ax=b.
% input: Q,c,A,b; out_iter, in_iter, tol, beta
% output: x
% somehow this is bad...

function x = qp_cduni_const(Q,c,A,b,out_iter,in_iter,tol,beta)
% L(x,y) = 1/2*x'Qx+c'x+<y,Ax-b>+beta/2 |Ax-b|^2
% Note: grad_x(L(x,y))=Qx+c+A'y+beta*A'(Ax-b)
[n, d]=size(A);
x=zeros(d,1);
y=zeros(n,1);
%L=norm(Q)+beta*norm(A)^2; % grad lip const.
L=norm(Q+beta*A'*A); % use this when d is not so big. 
alpha = 1/L; % should backtrack. const step size is too bad.
for k=1:out_iter
    for l=1:in_iter
        j = unidrnd(d);
        x(j) = x(j) - alpha * (Q(j,:)*x+c(j)+A(:,j)'*y+beta*A(:,j)'*(A*x-b));
        %if mod(in_iter,5)==0 && norm(Q*x+c+A'*y+beta*A'*(A*x-b))<tol 
        % stop when |grad_x(L(x,y))| small. Should only check 2nd if 1st hold.
    end
    y=y+beta*(A*x-b);
    if norm(Q*x+c+A'*y+beta*A'*(A*x-b))<tol % stop when |grad_x(L(x,y))| small
            break % only check once a while. 
    end
end
end