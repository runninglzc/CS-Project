% Data: c; A,b ~ U[0,1]; Q ~ random PSD matrix with mean = I, covariance = I.
%%% Didn't consider x>=0! Need fix!
m=100;
n=500;
A=rand(m,n);
b=rand(m,1);
Q=wishrnd(eye(n),n/10); % 2nd parameter = degree of freedom.
temp=0.1; Q=Q+temp*eye(n); % in case not PSD. Problem harder as temp decreases.
c=rand(n,1);

tol=10^(-4); % (try) stop crit of FISTA: |grad(L(x^l,y^k))| < tol
out_iter=50; % # outer iteration
beta=1;
in_iter=5000; % max # inner iter [need it large to not diverge!]
%%
tic
[x objhist] = iALM_qp(Q,c,A,b,out_iter,in_iter,tol,beta); % FISTA
toc
%%
% tic
% x2 = qp_cduni(Q,c,A,b,out_iter,in_iter,tol,beta); 
% toc
%%
tic
[x3 objhist3] = qp_nuacdm(Q,c,A,b,out_iter,in_iter,tol,beta); %NUACDM
toc
%%
cvx_begin
    cvx_precision high
    variable xopt(n);
    minimize( 1/2*xopt'*Q*xopt+c'*xopt );
    subject to
    A*xopt==b;
cvx_end
obj_opt = cvx_optval;

%%
"fista:"
obj = 1/2*x'*Q*x+c'*x % obj
constr = norm(A*x-b) % constraint
%%
% obj2 = 1/2*x2'*Q*x2+c'*x2 % obj
% constr2 = norm(A*x2-b) % constraint
%%
"nuacdm:"
 obj3 = 1/2*x3'*Q*x3+c'*x3 % obj
 constr3 = norm(A*x3-b) % constraint
 %% Plot obj:
xaxis=1:out_iter;
plot(xaxis,objhist)
legend('FISTA')
title('QP obj, NUACDM vs FISTA')
xlabel('iter')
ylabel('obj')
hold on 
plot(xaxis,objhist3)
legend('NUACDM')