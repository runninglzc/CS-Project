% QP Solver: (iALM, FISTA)
% min 1/2*x'Qx+c'x s.t. Ax=b.
% input: Q,c,A,b; out_iter, in_iter, tol, beta
% output: x
%%% Didn't consider x>=0! Need fix!

function [x objhist] = iALM_qp(Q,c,A,b,out_iter,in_iter,tol,beta)
objhist=zeros(out_iter,1); % stores obj hist every out-iter
% L(x,y) = 1/2*x'Qx+c'x+<y,Ax-b>+beta/2 |Ax-b|^2
% Note: grad_x(L(x,y))=Qx+c+A'y+beta*A'(Ax-b)
[m n]=size(A);
%tol=10^(-6); % (try) stop crit of FISTA: |grad(L(x^l,y^k))| < tol
%out_iter=50; % # outer iteration
%beta=1;
%in_iter=500; % max # inner iter

x=zeros(n,1);
y=zeros(m,1);
%L=norm(Q)+beta*norm(A)^2; % grad lip const.
L=norm(Q+beta*A'*A); % use this when d is not so big. 
for k=1:out_iter
    z=x; % FISTA:
    t=1;
    for l=1:in_iter
        t_old=t;
        t=(1+sqrt(1+4*t^2))/2;
        x_old=x;
        x=z-(Q*z+c+A'*y+beta*A'*(A*z-b))/L;
        z=x+(t_old-1)/t*(x-x_old);
        if norm(Q*x+c+A'*y+beta*A'*(A*x-b))<tol % stop when |grad_x(L(x,y))| small.
            break
        end
    end
    y=y+beta*(A*x-b);
    obj = objf(x);
    objhist(k)=obj;
end

function r = objf(x)
r=1/2*x'*Q*x+c'*x;
end
end