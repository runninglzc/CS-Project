function [w,b,hist_obj,grad_w,grad_b] = LR_nuacdm_exact(X,y,lam1,lam2,maxit,tol)
% Exact implementation of NUACDM (no block)
% only save obj every 100 iter.
% nuacdm: j ~ sqrt(L_j), instead of cyclic/uniform. Can pre-approx L_j:
% L_j ~ lm1 + 1/N sum_{i=1}^n x_{ij}^2 = lm1+1/N sum|x(:,j)|^2.
% Old Results:
% spamdata, tol=0.01, maxit=2000: 40 sec. 88%, 90%.
%   the while loop in backtrack is most time-consuming. idk what i can do
%   to improve... p is the issue (~96% chance to select last index)
% gisette, tol=0.01, ite=264*5: 8 sec. 100%, 93.4%
% gisette, tol=0.0001, ite=4493*5: 135 sec, 100%, 93.6%
%
% New(good) Results:
% spamdata, tol=0.01, maxit=10^7: 57 sec (645980 iter). 91%, 93% (nuacdm_lr_1e-2.jpg)
% gisette, tol=0.01, maxit=10^7: 451 sec (559999 iter). 100%, 93.1% (nuacdm_lr_gis.jpg)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% steepest gradient descent for logistic regression problem:
%
% min_{w,b} 1/N*sum_{i=1}^N log( 1+exp[-yi*(w'*xi+b)] ) 
%           + .5*lam1*w'*w + .5*lam2*b^2 
%
% input:
%       X(i,:) is the i-th data point
%       y(i) is the label
%       lam1, lam2: parameters in the model
%       maxit: maximum number of iterations
%       tol: stopping tolerance
%
% output:
%       w, b: approximation solution of the model
%       hist_obj: objective values at all iterates
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% get size of the data
%
% N is the number of sample points
% n is the dimension of each sample point

[N,n] = size(X);

%% initialization
w = zeros(n,1);
b = 0;
w1 = [w;b]; % whole variable
yy = w1; % GD iterate
zz = w1; % MD iterate
[grad_w, grad_b] = eval_grad(w,b); %%
obj = eval_obj(w,b); %%
hist_obj = obj;
iter = 0; 
% Pre-estimate L_i:
% could use L = lm1+1/N*y'.^2*X.^2, but below only take 0.001s so w.e.
L = zeros(n+1,1); % L_{n+1} is L_b
for j = 1:n
  Lj = lam1+norm(X(:,j))^2;
  L(j)=Lj;
end
L(n+1) = lam2+1; % might be a good idea to isolate bias. idk
p = zeros(n+1,1); % p contains prob of selecting each coord
for j = 1:n
    p(j)=sqrt(L(j)); % j ~ sqrt(L_j); generalize to block.
end
p(n+1) = L(n+1); % bias term
S = sum(p); % sum(sqrt(L_j))
p = p/S; % normalize
sigma = lam1; % strongly convex. assume lm1 = lm2
tau = 2/(1+sqrt(1+4*S^2/sigma));
eta = 1/(tau*S^2);
%% main iterations
tic
while iter < maxit  % 1 iter cost 0.0001 sec. 100 times faster than backtrack-cyclic!
    iter = iter + 1;
    w1 = tau*zz+(1-tau)*yy; % this extrapolation step is expensive.
    w = w1(1:n);
    b = w1(n+1);
        % now sample j:
       temp3 = rand; % ~U(0,1)
       temp4 = 0; % used below
       for temp5 = 1:n+1 % this for-loop cost 0.000006 sec. not issue.
           temp4 = temp4+p(temp5);
           if temp3 < temp4
               j = temp5;
               break
           end
       end
      if j < n+1 % i.e. not bias term:
       partial_w = eval_partial(w,b,j); %%% can optimize below:
       yy = w1;
       yy(j) = yy(j)-1/L(j)*partial_w ;
       zz = zz+eta*sigma*w1;
       zz(j) = zz(j)-eta/p(j)*partial_w;
       zz = 1/(1+eta*sigma)*zz;
      else % bias term:
          grad_b = eval_gradb(w,b);
       yy = w1;
       yy(j) = yy(j)-1/L(j)*grad_b ;
       zz = zz+eta*sigma*w1;
       zz(j) = zz(j)-eta/p(j)*grad_b;
       zz = 1/(1+eta*sigma)*zz;
      end   
   % end
    % below step is only use to check stop crit!! not good too often!!
    if mod(iter,n)==n-1 % only check every n iter...
      [grad_w, grad_b] = eval_grad(w,b);
       if norm(grad_w) + norm(grad_b) < tol*max(1, norm(w)+norm(b))
           norm(grad_w)
           norm(grad_b)
           max(1, norm(w)+norm(b))
           iter
           break
       end
    end
    if mod(iter,100)==0
      obj = eval_obj(w,b); % save the objective value every 100 iter
      hist_obj = [hist_obj; obj];
    end
    %iter
end % of main iteration
toc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function [grad_b] = eval_gradb(w,b) % avoid for loop!     
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        grad_b=lam2*b+sum(temp);
    end 
    function [partial_w] = eval_partial(w,b,j) % (removed block)
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        partial_w=lam1*w(j)+(temp*X(:,j))';
    end 
    function [grad_w, grad_b] = eval_grad(w,b) % avoid for loop!      
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        grad_w=lam1*w+(temp*X)';
        grad_b=lam2*b+sum(temp);
    end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    function obj = eval_obj(w,b) % avoid for loop! 
        obj=lam1/2*norm(w)^2+lam2/2*b^2+sum(log(1+exp(-(X*w+b).*y))/N);
    end 

    function obj = eval_obj_partw(wj,j) % s.t. calling avoids extrapolation
        % we care about jth block. wj is the vector of jth block.
        tempw = w;
        tempw(k*(j-1)+1:k*j) = wj;
        obj = eval_obj(tempw,b);
    end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end