%% train accuracy
total_Tcount=size(ytrain,1);
Tcount=0;
for i=1:total_Tcount
    if (Xtrain(i,:)*w+b)*ytrain(i)>0
        Tcount=Tcount+1;
    end
end
Tcount/total_Tcount

%% test accuracy:
total_count=size(ytest,1);
count=0;
for i=1:total_count
    if (Xtest(i,:)*w+b)*ytest(i)>0
        count=count+1;
    end
end
count/total_count

% %% plot obj
% xaxis=1:length(hist_obj);
% plot(xaxis,hist_obj)
% title('gisette cgd 3 per block')
% xlabel('iter')
% ylabel('objective')

%% plot (semilog) obj error
opt_spam=0.22986663; % 0.229866627850900 (382 iter, 21 sec) for spamData. 
opt_gis=0.004202409665496; % 0.004202409665496 (84 iter, 102 sec) for gisette.
xaxis=1:length(hist_obj);
xaxis=1:100:100*length(hist_obj); % in NUACDM, I plot every 100 iter!
semilogy(xaxis,hist_obj-opt_gis)
title('gisette nuacdm (semilog)')
xlabel('iter')
ylabel('log obj err')