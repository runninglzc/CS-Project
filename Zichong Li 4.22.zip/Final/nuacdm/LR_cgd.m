function [w,b,hist_obj,grad_w,grad_b] = LR_cgd(X,y,lam1,lam2,maxit,tol,k) % ok use this for steepest GD
% k: # of coordinates in each block. Need N/k to be integer.
%%% Update: FIX BACKTRACK!!! not efficient!!!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% steepest gradient descent for logistic regression problem:
%
% min_{w,b} 1/N*sum_{i=1}^N log( 1+exp[-yi*(w'*xi+b)] ) 
%           + .5*lam1*w'*w + .5*lam2*b^2 
%
% input:
%       X(i,:) is the i-th data point
%       y(i) is the label
%       lam1, lam2: parameters in the model
%       maxit: maximum number of iterations
%       tol: stopping tolerance
%
% output:
%       w, b: approximation solution of the model
%       hist_obj: objective values at all iterates
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% get size of the data
%
% N is the number of sample points
% n is the dimension of each sample point

[N,n] = size(X);

%% initialization
%
% other initial iterate can also be used
w = zeros(n,1);
b = 0;

% grad_w: the partial gradient of w
% grad_b: the partial gradient of b

% write your own function eval_grad to evaluate grad_w and grad_b
[grad_w, grad_b] = eval_grad(w,b); %%

% write your own function eval_obj(w,b)
obj = eval_obj(w,b); %%
hist_obj = obj;
iter = 0; 

%% main iterations
while iter < maxit & ... % 1 iter cost 0.01 sec
        norm(grad_w) + norm(grad_b) >= tol*max(1, norm(w)+norm(b))
    
    iter = iter + 1;
    % "write your own code to choose the step size alpha:"
    % Armijo's Cond: (s \in (0,1). ex: s=1/2) 
    % Backtrack: start from 0.1, *1/2 every time Armijo fails. (can change)
    %alpha1 = 0.1;
    alpha2 = 0.1;% (can change)
    s=1/2; % (can change)
    % if backtracking is used, another while-loop should be inserted here:
    for i = 1:n/k % this for-loop cost 0.01 sec
       alpha1 = 0.1;
       partial_w = eval_partial(w,b,i);
       v = zeros(n,1);
       v(k*(i-1)+1:k*i) = partial_w;
      while eval_obj(w-alpha1*v,b) ... % 0.0002 sec, occasionally 0.003
            > eval_obj(w,b)-s*alpha1*(norm(v)^2)
        alpha1=1/2*alpha1; % (can change)
      end
      w((k*(i-1)+1:k*i)) = w((k*(i-1)+1:k*i)) - alpha1*partial_w;
    end
    
    [grad_b] = eval_gradb(w,b);
    while eval_obj(w,b-alpha2*grad_b) ... % ok maybe this is expensive. 
            > eval_obj(w,b)-s*alpha2*(norm(grad_b)^2) % should not extrapolate every point.
  % also should compute norm(grad_b) and eval_obj(w,b) before while loop!!!
        alpha2=1/2*alpha2; % (can change)
    end
    %alpha
    % update w and b
    b = b - alpha2*grad_b;
       
    % evaluate the gradient for next iteration
    %if mod(iter,5)==0 %%%
        [grad_w, grad_b] = eval_grad(w,b); %%% This step is so stupid if done too often...
   % end %%%
    % write your own function eval_obj(w,b)
    obj = eval_obj(w,b);
    
    % save the objective value
    hist_obj = [hist_obj; obj];
    
    %iter
end % of main iteration


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%     function [grad_w, grad_b] = eval_grad(w,b)
%         
%         grad_w=lam1*w;
%         grad_b=lam2*b;
%         for i=1:N           
%             temp=y(i)/N*(1-1/(1+exp(-y(i)*(X(i,:)*w+b)))); % a little faster than original [
%             grad_w=grad_w-temp*X(i,:)'; 
%             grad_b=grad_b-temp; % ]
%         end
%         % complete this function
%         
%     end % of function eval_grad

    function [grad_b] = eval_gradb(w,b) % avoid for loop!     
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        grad_b=lam2*b+sum(temp);
    end 
    function [partial_w] = eval_partial(w,b,i) % avoid for loop!     
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        partial_w=lam1*w(k*(i-1)+1:k*i)+(temp*X(:,k*(i-1)+1:k*i))';
    end 
    function [grad_w, grad_b] = eval_grad(w,b) % avoid for loop!      
        temp=-y'./(1+exp((w'*X'+b).*y'))/N;
        grad_w=lam1*w+(temp*X)';
        grad_b=lam2*b+sum(temp);
    end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%     function obj = eval_obj(w,b)
%         
%         obj=lam1/2*norm(w)^2+lam2/2*b^2;
%         for i=1:N
%             obj=obj+1/N*log(1+exp(-y(i)*(X(i,:)*w+b)));
%         end
%         
%         % complete this function
%     end % of function eval_obj

    function obj = eval_obj(w,b) % avoid for loop! 
        obj=lam1/2*norm(w)^2+lam2/2*b^2+sum(log(1+exp(-(X*w+b).*y))/N);
    end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end